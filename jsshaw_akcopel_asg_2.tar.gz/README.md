# CPSC3600 Assignment 2 - Can you Ping it?

Created by Spencer Shaw and Adam Copeland - Clemson Univeristy Spring 2022
